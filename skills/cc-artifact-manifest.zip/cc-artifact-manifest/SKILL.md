---
name: cc-artifact-manifest
description: Track files and artifacts created during sessions. Maintain a running manifest so nothing is lost on context compaction.
---

# Artifact Manifest

During a session, files and artifacts may be created — documents, code, specs, ODRC output files, diagrams, or other deliverables. The artifact manifest tracks every created item so that if the session is compacted or context is lost, the work can be recovered.

## Manifest Format

Maintain a running manifest as a markdown table. Update it every time a file is created or modified.

```markdown
## Artifact Manifest
| # | Filename | Type | Status | Purpose |
|---|----------|------|--------|---------|
| 1 | CC-Ideation-Spec.md | spec | complete | Ideation workflow specification |
| 2 | ODRC-Updates-Session-3.md | odrc | complete | Session ODRC output |
| 3 | index.html | code | in-progress | Updated CC source with new feature |
```

### Fields
- **#** — Sequential number for reference
- **Filename** — Exact filename as created
- **Type** — One of: spec, odrc, code, doc, config, test, other
- **Status** — One of: complete, in-progress, draft, superseded
- **Purpose** — Brief description of what the file is for

## When to Update

- **File created** → Add entry with status
- **File modified significantly** → Update status or add note
- **File superseded** → Mark old entry as "superseded", add new entry
- **Session closing** → Review manifest for completeness before producing post-session package

## Recovery After Compaction

If the session is compacted, the manifest serves as the recovery index. Claude should:

1. Check if a manifest was produced earlier in the session
2. Use it to identify which files exist and their state
3. Verify files still exist in the working directory
4. Resume work with awareness of what's been produced

## Guidelines

- Keep the manifest in working memory throughout the session — don't wait until the end
- If multiple versions of a file are created, track each version
- The manifest becomes part of the post-session package
- For long sessions with many artifacts, periodically echo the manifest to the developer so it's captured in the conversation history
