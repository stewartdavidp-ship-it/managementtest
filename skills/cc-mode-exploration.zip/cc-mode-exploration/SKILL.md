---
name: cc-mode-exploration
description: Exploration mode for ideation sessions. Open discovery focused on surfacing OPENs and making early Decisions. Use for new or early-stage ideas.
---

# Exploration Mode

Exploration mode is for open-ended discovery. The goal is to map the terrain of an idea — surface what's unknown, make early directional decisions, and identify the boundaries of the problem space.

## Posture

- **Curious, not challenging** — Exploration asks "what if" and "how might we", not "prove to me that"
- **Breadth first, then depth** — Start by mapping the full scope before drilling into any one area
- **Bias toward surfacing OPENs** — In early exploration, finding the right questions is more valuable than finding answers
- **Make easy Decisions quickly** — Don't deliberate on obvious choices. Decide and move on to harder questions.

## Session Flow

### Phase 1: Orientation (first 10-15 minutes)
- Understand the idea at a high level
- Identify the core problem being solved
- Map the major components or dimensions
- Establish what's known vs unknown

### Phase 2: Systematic Probing (bulk of session)
- Work through the lens domain systematically
- For each area: What do we know? What don't we know? What can we decide now?
- Capture OPENs as they surface — don't try to resolve everything immediately
- Make Decisions when the information is sufficient — don't defer unnecessarily
- Note Rules and Constraints as they emerge from the discussion

### Phase 3: Synthesis (last 10-15 minutes)
- Review what was covered and what wasn't
- Count OPENs vs Decisions — are we progressing or just generating questions?
- Identify clusters of related OPENs that could be a single focused session
- Recommend next session lens/mode based on where the gaps are

## Output Emphasis

Exploration sessions typically produce:
- **More OPENs than Decisions** — this is expected and healthy for early-stage ideas
- **Broad coverage** — many topics touched, not all resolved
- **Directional Decisions** — "we're going this way" without full specification
- **Early Constraints** — fundamental boundaries discovered

## Guidelines

- Don't force closure on topics that need more research — capture the OPEN and move on
- If the developer has strong convictions, capture them as Decisions with rationale rather than questioning everything
- Track which areas of the lens were covered and which were skipped — this feeds coverage gap analysis
- If the idea is more mature than expected (developer has many answers already), shift toward making Decisions rather than just probing — don't artificially hold back

## When Exploration Mode Is Wrong

If the developer already has extensive ODRC state (many Decisions, few OPENs), exploration mode will feel frustrating — they'll feel like they're retreading ground. Suggest a different mode:
- Many Decisions but untested → stress test mode
- Decisions made but not specified → spec mode
- Need to evaluate what exists → review mode
