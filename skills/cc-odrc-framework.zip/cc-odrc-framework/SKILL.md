---
name: cc-odrc-framework
description: ODRC thinking framework for ideation sessions. Use when exploring ideas, making decisions, or producing structured session output for Command Center.
---

# ODRC Framework

ODRC is the structured thinking framework for all ideation work managed through Command Center. Every ideation session uses ODRC to organize thinking and produce ingestible output.

## The Four ODRC Categories

### OPENs
Questions, uncertainties, or unresolved issues that need investigation or decision. OPENs represent gaps in understanding.

- Phrased as specific, actionable questions — not vague
- Good: "How does the system handle concurrent edits from multiple users?"
- Bad: "Need to figure out the architecture"
- OPENs are the primary driver of session work — the goal is to resolve them into Decisions or surface new ones

### DECISIONs
Resolved positions on how something should work, what to build, or which direction to take. Decisions include rationale.

- Must include both WHAT was decided AND WHY
- Good: "Use WebSocket for real-time sync because polling would create unacceptable latency at scale"
- Bad: "Use WebSocket"
- Decisions are cumulative — they build on each other across sessions

### RULEs
Behavioral principles that govern how future work should be done. Rules are patterns, not one-time choices.

- Rules apply broadly and repeatedly, not to a single instance
- Good: "All API responses must include pagination metadata even if the result set is small"
- Bad: "Paginate the user list endpoint"
- Rules often emerge from Decisions that reveal a repeatable pattern

### CONSTRAINTs
Hard boundaries that cannot be changed — technology limits, policy requirements, scope boundaries, resource caps.

- Constraints are facts, not choices — they exist whether you like them or not
- Good: "Claude.ai limits custom skills to ~20 per account"
- Bad: "We should limit the number of skills" (that's a Decision)
- Constraints shape what's possible and often generate OPENs about workarounds

## How ODRC Drives Sessions

Every session should actively work toward:
1. **Surfacing OPENs** — finding the questions that haven't been asked yet
2. **Resolving OPENs into Decisions** — making choices with clear rationale
3. **Recognizing Rules** — identifying patterns that should govern future work
4. **Identifying Constraints** — documenting hard boundaries early

The distribution of ODRC items signals idea maturity:
- Many OPENs, few Decisions → early exploration
- Decisions outnumber OPENs, Rules emerging → converging
- OPENs near zero, strong Rules and Constraints → spec-ready

## ODRC Output Format

Every session must end with a structured ODRC Updates section. This format is machine-parseable by Command Center.

```markdown
# ODRC Updates — [Idea Name]
# Date: YYYY-MM-DD
# Session: S-YYYY-MM-DD-NNN (brief description)
# Idea: idea-slug
# IdeaId: [Firebase ID if known]
# App: app-name
# Context: (one-line summary of what this session accomplished)

- RESOLVE OPEN: "original open text" → resolution with rationale
- NEW DECISION: "what was decided AND why — enough context to understand standalone"
- NEW OPEN: "specific actionable question — not vague"
- NEW RULE: "behavioral principle governing future work"
- NEW CONSTRAINT: "hard boundary — technology, scope, policy"

## Session Notes
### What Was Accomplished
(Narrative paragraph summarizing the session)

### Key Design Principles Established
- (Bulleted themes that emerged)

### Session Status
- Concepts: X OPENs, X DECISIONs, X RULEs, X CONSTRAINTs
- Phase: (exploring | converging | spec-ready)
- Next session: (what to focus on next)
```

## Guidelines

- Frame ALL exploration in ODRC terms — don't just discuss, categorize
- Challenge vague OPENs — push for specificity
- When a Decision is made, immediately check: does this create new OPENs? Does it reveal a Rule?
- Track resolved OPENs explicitly — "RESOLVE OPEN" shows progress
- Every ODRC line must be self-contained — someone reading just that line should understand the decision without needing session context
