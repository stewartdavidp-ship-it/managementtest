---
name: cc-lens-technical
description: Technical lens for ideation sessions. Probes feasibility, architecture, dependencies, implementation risk, and technical constraints.
---

# Technical Lens

This lens focuses the session on technical aspects of an idea. When the session brief specifies the technical lens, use this skill to guide what questions to ask and what ODRC categories to look for.

## What This Lens Examines

- **Feasibility** — Can this actually be built? What are the hard technical problems?
- **Architecture** — How should components be structured? What patterns apply?
- **Dependencies** — What does this rely on? External services, APIs, libraries, platforms?
- **Implementation risk** — What could go wrong during build? What's uncertain?
- **Technical debt** — What shortcuts would we take and what's the cost?
- **Integration** — How does this connect to existing systems?
- **Performance** — Will it work at the required scale and speed?
- **Security** — What are the attack surfaces and data risks?

## Probing Framework

### Start Broad, Then Dig
Begin with the high-level technical approach, then drill into specific components. Don't jump to implementation details before the architecture is clear.

### Question Patterns

**Feasibility probes:**
- "What's the hardest technical problem in this idea?"
- "Is there anything here that you're not sure can be done?"
- "What would you prototype first to reduce risk?"

**Architecture probes:**
- "Walk me through how data flows from input to output"
- "What are the major components and how do they communicate?"
- "Where does state live? Who owns it?"

**Dependency probes:**
- "What external services does this require?"
- "What happens if [dependency] goes down or changes its API?"
- "Are there licensing or cost implications for these dependencies?"

**Implementation risk probes:**
- "What part of this would you estimate poorly?"
- "Where are the unknowns that could blow up the timeline?"
- "Have you built something like [component] before?"

**Integration probes:**
- "How does this interact with existing systems?"
- "What data needs to be shared between this and other components?"
- "Are there version compatibility concerns?"

## ODRC Tendencies

Technical lens sessions tend to produce:
- **Constraints** frequently — platform limits, API rate limits, browser capabilities, performance ceilings
- **Rules** about architecture patterns, coding conventions, integration approaches
- **OPENs** about feasibility of specific components and implementation approaches
- **Decisions** about technology choices, architecture patterns, build-vs-buy

## Depth Signals

You're going deep enough when:
- The developer says "I don't know" or "I'd need to research that" → OPEN captured
- Specific technology names, version numbers, and API endpoints are being discussed
- Trade-offs between approaches are being weighed with concrete criteria
- Edge cases and failure modes are being identified

You're too shallow when:
- The conversation stays at the level of "we'd use a database" without specifying which and why
- No Constraints have been identified (every technical idea has technical constraints)
- Implementation risks haven't been discussed
