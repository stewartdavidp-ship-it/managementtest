---
name: cc-session-structure
description: Session protocol for Command Center ideation sessions. Defines opening, pacing, compaction recovery, and closing procedures.
---

# Session Structure

This skill defines how to run a Command Center ideation session from open to close.

## Session Opening

When a session begins:

1. **Review the session brief** — The brief contains the idea context, ODRC state, and session goal. Confirm you've reviewed it.
2. **Identify which skills to read** — The brief specifies which lens and mode skills apply. Read them before proceeding.
3. **Confirm the goal** — Ask the developer what they want to accomplish. Don't assume from the brief alone — the developer may have shifted focus.
4. **Establish scope** — A focused session produces better ODRC output than a broad one. If the goal is too wide, suggest narrowing to a specific domain or question set.

## Session Pacing

### Check-ins
At natural transition points (roughly every 15-20 minutes of conversation or after resolving a cluster of related topics):
- Summarize what's been decided so far
- Count OPENs resolved vs new OPENs surfaced
- Ask if the developer wants to continue in this direction or shift

### Depth Over Breadth
Push deep on each topic before moving to the next. Surface-level coverage of many topics produces vague OPENs. Deep examination of fewer topics produces specific Decisions, Rules, and Constraints.

### Recognizing Completion Signals
- The same questions keep circling without new information → topic is exhausted
- Developer starts answering with high confidence and specificity → Decisions are forming
- "That's a good question, I don't know" → valuable OPEN surfaced, move on
- Energy shifts to a different topic → follow the energy, capture the pivot

## Compaction Recovery

If the session is compacted (context window limit reached), Claude will see a summary rather than the full conversation. When this happens:

1. **Check for transcripts** — Run `ls /mnt/transcripts/` and review any transcript files
2. **Review the transcript** — Start with the end (most recent context), then earlier sections
3. **Extract key context** — file paths, version numbers, decisions made, current work state
4. **Confirm with the developer** — "I've reviewed the transcript. We were working on [X]. Should I continue with [Z]?"
5. **Consult the artifact manifest** — If an artifact manifest was being maintained, it shows what files were created and their status

## Session Closing

When the session is wrapping up (developer signals completion, or significant progress has been made):

1. **Produce the ODRC Updates** — Follow the format defined in the cc-odrc-framework skill
2. **Include Session Notes** — What was accomplished, key principles, session status
3. **Recommend next session** — Based on remaining OPENs and coverage gaps, suggest what lens/mode to use next
4. **Produce the post-session package** — Follow the cc-post-session-package skill

## Session Principles

- **Every session is additive** — No session output is throwaway. Each conversation advances the cumulative ODRC state.
- **The developer drives direction** — Skills provide structure, not control. If the developer wants to diverge, follow them and capture what emerges.
- **ODRC framing is continuous** — Don't save categorization for the end. Name OPENs, Decisions, Rules, and Constraints as they emerge during conversation.
- **Bias toward decisions** — It's easy to surface questions. The hard work is making choices. Push for decisions when enough information exists.
