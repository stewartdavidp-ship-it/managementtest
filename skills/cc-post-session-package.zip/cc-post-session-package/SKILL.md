---
name: cc-post-session-package
description: Defines what a session must produce as output for Command Center ingestion. Use at session close to ensure complete deliverables.
---

# Post-Session Package

Every ideation session must produce a structured output package that Command Center can ingest. This skill defines the required deliverables and their format.

## Required Output

### 1. ODRC Updates Document
The primary deliverable. Follows the format defined in the cc-odrc-framework skill.

**Filename pattern:** `ODRC-Updates-{Idea-Slug}-S{NNN}-{YYYY-MM-DD}.md`

Must include:
- Header block with metadata (date, session ID, idea, app, context)
- All ODRC items produced during the session (NEW and RESOLVE)
- Session Notes section (what was accomplished, key principles, status, next session)

Each ODRC line must be self-contained — readable and understandable without the full session context.

### 2. Artifact Manifest
A summary of every file created during the session, following the cc-artifact-manifest skill format.

Include this as a section within the ODRC Updates document or as a separate file if the session produced many artifacts.

### 3. Session Artifacts
Any files created during the session that should be preserved:
- Specification documents
- Code files
- Diagrams or reference materials
- Updated configuration files

## Optional Output

### Brief Update Recommendations
If the session revealed that the session brief template should be adjusted for future sessions, note the recommendation. For example:
- "Brief should include architecture diagram for technical sessions"
- "ODRC state was missing 3 Decisions from a prior session — brief generation may have a gap"

### Coverage Gap Analysis
Based on the ODRC state after this session, note which lenses or modes would be valuable for the next session:
- "Economic viability has not been examined — recommend economics lens next"
- "Multiple Decisions made without stress testing — consider a stress test session"

## Output Quality Checklist

Before finalizing the post-session package, verify:

- [ ] Every ODRC line includes rationale, not just a label
- [ ] OPENs are phrased as specific questions, not vague topics
- [ ] Decisions include both what AND why
- [ ] Session Notes accurately summarize what happened
- [ ] Next session recommendation is actionable
- [ ] Artifact manifest is complete
- [ ] All referenced files are included in the package

## Delivery

Produce the ODRC Updates document as a downloadable markdown file. If additional artifacts were created, package them together. The developer will upload these to Command Center for ingestion into the idea's ODRC state.
